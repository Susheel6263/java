package assginment4;

import java.util.Date;

public class Vender extends Employee{

	private int noe;
	private double amount;
	
	public Vender()
	{
		super();
		noe=0;
		amount=0;
	}
	public Vender( String name, String mobno, String emailid, String dept, String desg, Date doj,int noe,double amount)
	{
		super("Vendor",name,mobno,emailid,dept,desg,doj);
		this.noe=noe;
		this.amount=amount;
	}
	public int getNoe() {
		return noe;
	}
	public double getAmount() {
		return amount;
	}
	public void setNoe(int noe) {
		this.noe = noe;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	public String toString() {
		return super.toString()+"\n noe=" + noe + "\n amount=" + amount +"\n-----------------------------------" ;
		
	}
	@Override
	public void calSal() {
		
		//calculating amount for vender
		
		System.out.println(" having amount "+(amount+amount*0.18*noe)+" Rs.");
			}
	
}



