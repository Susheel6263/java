package assginment4;

import java.time.LocalDate;
import java.util.Date;

public class ContractEmployee extends Employee{
 
	private  int hrs;
    private int rate;
    
    public ContractEmployee()
    {
    	super();
    	hrs=0;
    	rate=0;
    }
    
    public ContractEmployee(String name, String mobno, String emailid, String dept, String desg, Date doj,int hrs,int rate) 
    {
		super("Contract Employee",name,mobno,emailid,dept,desg,doj);
		this.hrs=hrs;
		this.rate=rate;
    }

	
	public int getHrs() {
		return hrs;
	}

	public int getRate() {
		return rate;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public String toString() {
		return super.toString()+"\n hrs=" + hrs + "\n rate=" + rate +"\n-----------------------------------" ;
	}

	@Override
	public void calSal() {
		
		//calculating salary for contract employee
		
		System.out.println(" having charges "+(hrs*rate)+" Rs.");
		
	}
    
    
}




