package assginment4;

import java.util.Date;

public class EmployeeService {

	public static Employee[] earr;
	private static int count;
	static {
		earr= new Employee[50]; 
        earr[0] = new SalariedEmployee( "kiran", "54871254", "uyhgsvdrf@gmail.com", "IT", "Software Engineer", new Date(), 54871);
        earr[1] = new Vender( "naman", "65982365", "asdfghj@gmail.com", "Business Development", "Account Manager", new Date(), 10, 6000);
        earr[2] = new SalariedEmployee( "riya", "78451296", "qwertyui@gmail.com", "HR", "HR Assistant", new Date(), 45000);
        earr[3] = new ContractEmployee( "vikas", "96325874", "zxcvbnm@gmail.com", "Technology", "Senior Developer", new Date(), 25, 1500);
        earr[4] = new SalariedEmployee( "sneha", "85214796", "poiuytre@gmail.com", "Healthcare", "Physician", new Date(), 90000);
        earr[5] = new ContractEmployee( "rajesh", "12345678", "lkjhgfdsa@gmail.com", "Finance", "Financial Analyst", new Date(), 34, 2050);
        earr[6] = new SalariedEmployee( "deepika", "98761234", "mnbvcxz@gmail.com", "Marketing", "Marketing Specialist", new Date(), 62000);
        earr[7] = new Vender( "sumit", "45678912", "asdfghjkl@gmail.com", "Supply Chain", "Logistics Coordinator", new Date(), 15, 6800);
        earr[8] = new ContractEmployee( "anjali", "74185296", "qwertyuiop@gmail.com", "Administration", "Office Manager", new Date(), 30, 520);
        earr[9] = new SalariedEmployee( "rohit", "36925814", "zxcvbnmasd@gmail.com", "Research and Development", "Research Scientist", new Date(), 58000);
        earr[10] = new Vender( "shweta", "85296374", "plokmijn@gmail.com", "Software Development", "Team Lead", new Date(), 17, 7500);
        earr[11] = new SalariedEmployee( "prakash", "14725836", "edcftrgy@gmail.com", "Science", "Senior Scientist", new Date(), 82000);
        earr[12] = new ContractEmployee("neha", "96385274", "wsxzaqwert@gmail.com", "Creative", "Graphic Designer", new Date(), 40, 650);
        earr[13] = new SalariedEmployee( "sagar", "25836914", "ujhygtfrd@gmail.com", "Legal", "Legal Counsel", new Date(), 78000);
        earr[14] = new Vender( "pooja", "74125896", "ikolpmnb@gmail.com", "Training", "Corporate Trainer", new Date(), 20, 5100);
        earr[15] = new SalariedEmployee( "akash", "36985214", "rfgyhujik@gmail.com", "Technical Support", "Support Engineer", new Date(), 56000);
        earr[16] = new ContractEmployee("divya", "85214736", "vbgfcdxsza@gmail.com", "Management", "Project Manager", new Date(), 24, 480);
        earr[17] = new SalariedEmployee("mahesh", "14785236", "oiuytrewq@gmail.com", "Facilities", "Maintenance Supervisor", new Date(), 42000);
        earr[18] = new Vender("jyoti", "96321485", "asdfghjklz@gmail.com", "Sales", "Sales Executive", new Date(), 10, 5300);
        earr[19] = new ContractEmployee("suresh", "25896314", "mnbvcxzlk@gmail.com", "Manufacturing", "Production Engineer", new Date(), 21, 600);
        earr[20] = new SalariedEmployee("kavita", "74185239", "qazwsxedcrf@gmail.com", "Strategy", "Business Analyst", new Date(), 72000);
        earr[21] = new Vender("amarnath", "36925871", "edcrfvtgby@gmail.com", "Transportation", "Logistics Manager", new Date(), 10, 5900);
        earr[22] = new SalariedEmployee("deepak", "85296317", "rfvtgbyhnuj@gmail.com", "Quality Assurance", "QA Lead", new Date(), 66000);
        earr[23] = new ContractEmployee("rani", "14725893", "yhnujmikolp@gmail.com", "Infrastructure", "Network Engineer", new Date(), 24, 490);
        earr[24] = new Vender("vijay", "96385217", "plokmijnuhby@gmail.com", "Environment", "Sustainability Officer", new Date(), 5, 6300);
        earr[25] = new SalariedEmployee("namrata", "11223344", "namrata@example.com", "Accounting", "Senior Accountant", new Date(), 59000);
        earr[26] = new ContractEmployee("vivek", "55667788", "vivek@example.com", "Customer Service", "Support Specialist", new Date(), 30, 580);
        earr[27] = new Vender("geeta", "99001122", "geeta@example.com", "Advertising", "Media Buyer", new Date(), 12, 7100);
        earr[28] = new SalariedEmployee("sanjay", "33445566", "sanjay@example.com", "Retail", "Store Manager", new Date(), 51000);
        earr[29] = new ContractEmployee("anjali", "77889900", "anjali@example.com", "Event Management", "Event Coordinator", new Date(), 35, 490);
        earr[30] = new Vender("mohan", "12300045", "mohan@example.com", "Consulting", "Management Consultant", new Date(), 8, 6500);
        earr[31] = new SalariedEmployee("shilpa", "67800012", "shilpa@example.com", "Product Development", "Product Manager", new Date(), 71000);
        earr[32] = new ContractEmployee("rajat", "23400056", "rajat@example.com", "UX/UI", "UX Designer", new Date(), 28, 620);
        earr[33] = new Vender("kirti", "78900012", "kirti@example.com", "Compliance", "Compliance Officer", new Date(), 15, 8200);
        earr[34] = new SalariedEmployee("amit", "34500067", "amit@example.com", "Academia", "Professor", new Date(), 60000);
        earr[35] = new ContractEmployee("riya", "89000123", "riya@example.com", "Public Relations", "PR Specialist", new Date(), 32, 530);
        earr[36] = new Vender("sunil", "45600078", "sunil@example.com", "Real Estate", "Property Manager", new Date(), 11, 7800);
        earr[37] = new SalariedEmployee("preeti", "90100023", "preeti@example.com", "Security", "Security Analyst", new Date(), 48000);
        earr[38] = new ContractEmployee("sachin", "56700089", "sachin@example.com", "Hospitality", "Hotel Manager", new Date(), 26, 570);
        earr[39] = new Vender("deepa", "12000034", "deepa@example.com", "Automotive", "Automotive Engineer", new Date(), 9, 6900);
        earr[40] = new SalariedEmployee("vivek", "67000045", "vivek@example.com", "Planning", "Urban Planner", new Date(), 75000);
        earr[41] = new ContractEmployee("shalu", "23000056", "shalu@example.com", "Aviation", "Aerospace Engineer", new Date(), 29, 510);
        earr[42] = new Vender("rajni", "78000067", "rajni@example.com", "Pharmaceuticals", "Research Scientist", new Date(), 14, 7300);
        earr[43] = new SalariedEmployee("gaurav", "34000078", "gaurav@example.com", "Construction", "Civil Engineer", new Date(), 61000);
        earr[44] = new ContractEmployee("nikita", "89000012", "nikita@example.com", "Environmental", "Environmental Scientist", new Date(), 31, 640);
        earr[45] = new Vender("alok", "45000023", "alok@example.com", "Banking", "Bank Manager", new Date(), 16, 8100);
        earr[46] = new SalariedEmployee("rashi", "90000034", "rashi@example.com", "Education", "School Principal", new Date(), 53000);
        earr[47] = new ContractEmployee("kunal", "56000045", "kunal@example.com", "Sports", "Sports Analyst", new Date(), 27, 590);
        earr[48] = new Vender("sonali", "12000056", "sonali@example.com", "Insurance", "Insurance Agent", new Date(), 13, 7600);
        earr[49] = new SalariedEmployee("umesh", "67000089", "umesh@example.com", "Telecommunications", "Network Administrator", new Date(), 64000);
	}
	public static void displayEmpWithSameDept(int c) {
		if(c>0 && c<4)
		{
		if(c==1) {
			for(int i=0;i<earr.length;i++)
			{
				if(earr[i] instanceof SalariedEmployee)
				{
					System.out.println(earr[i]);
				}
			}
		}
		else if(c==2)
		{
			for(int i=0;i<earr.length;i++)
			{
				if(earr[i] instanceof ContractEmployee)
				{
					System.out.println(earr[i]);
				}
			}
		}
		else
		{
			for(int i=0;i<earr.length;i++)
			{
				if(earr[i] instanceof Vender)
				{
					System.out.println(earr[i]);
				}
			}
		}
		}
		else
		{
			System.out.println("No Type Of Employee........");
		}
		
	}
	public static void searchById(int id) {
		
		for(int i=0;i<earr.length;i++)
		{
			if(earr[i]!=null)
			{
			if(earr[i].getId()==id)
			{
				System.out.println(earr[i]);
			}
			}
		}
		
	}
	public static void searchByName(String name) {

         for(int i=0;i<earr.length;i++)
         {
        	 if(earr[i]!=null)
        	 {
        		 if(earr[i].getName().equals(name))
        		 {
        			 System.out.println(earr[i]);
        		 }
        	 }
         }
		
		
	}
	public static void displayAllEmp() {
		
		for(int i=0;i<earr.length;i++)
		{
			if(earr[i]!=null) {
				System.out.println(earr[i]);
			}
			
		}
		
	}
	public static void empsOfDesgWithSameSal() {
		
		for(int i=0;i<earr.length;i++)
		{
			 System.out.print(earr[i].getName() + " - ");
	            earr[i].calSal();
	            System.out.println(" working on " + earr[i].getDesg() + " position.");
	             System.out.println("-------------------------------------------------------");        
		}

	}
	public static void empOfDept(String dept) {
		
		for(int i=0;i<earr.length;i++)
		{
			if(earr[i]!=null)
			{
				if(earr[i].getDept().equals(dept))
				{
					System.out.println(earr[i]);
				}
			}
		}
		
		}
		
	}
	
	

