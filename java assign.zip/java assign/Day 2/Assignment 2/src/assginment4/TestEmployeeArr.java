package assginment4;

import java.util.Scanner;
public class TestEmployeeArr {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int choice=0;
		do{
			System.out.println("1. Display All employees having same type \n 2. Search by id \n 3.Search by name \n 4.Display all employee \n 5.Salary for dept of same dept \n 6.5 Employees of a dept \n 7.Exit");
			System.out.println("Enter Choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:System.out.println("1.Salaried Employee \n 2.Contract Employee \n 3.Vender");
			       System.out.println("Enter your choice");
			       int c=sc.nextInt();
				   EmployeeService.displayEmpWithSameDept(c);
				break;
			case 2:int id;
			       System.out.println("Enter id:");
			       id=sc.nextInt();
				   EmployeeService.searchById(id);
				break;
			case 3:System.out.println("Enter name:");
			       String name=sc.next();
				  EmployeeService.searchByName(name);
				break;
			case 4:EmployeeService.displayAllEmp();
				break;
			case 5:EmployeeService.empsOfDesgWithSameSal();
				break;
			case 6:System.out.println("Enter Department:");
			       String dept=sc.next();
				   EmployeeService.empOfDept(dept);
				break;
			case 7:sc.close();
			       System.out.println("Thanks for Coming...........");
				break;
			default:System.out.println("Wrong Choice...!....");
			}
		}while(choice!=7);
	}

}


