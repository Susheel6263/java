package assginment4;

import java.text.SimpleDateFormat;
import java.util.Date;

public abstract class Employee {

	private int id;
	private String name;
	private String mobno;
	private String emailid;
	private String dept;
	private String desg;
	private Date doj;
	static int count;
	private String type;
	static {
		count=0;
	}
	public Employee() {
		super();
		this.type="Employee";
		this.id = 0;
		this.name = null;
		this.mobno = null;
		this.emailid = null;
		this.dept = null;
		this.desg = null;
		this.doj = null;
	}
	public Employee(String type, String name, String mobno, String emailid, String dept, String desg, Date doj) {
		super();
		this.type=type;
		this.id = generateId();
		this.name = name;
		this.mobno = mobno;
		this.emailid = emailid;
		this.dept = dept;
		this.desg = desg;
		this.doj = doj;
	}
	private int generateId() {
		count++;
		return count;
	}
	
	public String getName() {
		return name;
	}
	public String getMobno() {
		return mobno;
	}
	public String getEmailid() {
		return emailid;
	}
	public String getDept() {
		return dept;
	}
	public String getDesg() {
		return desg;
	}
	public Date getDoj() {
		return doj;
	}
	public int getId()
	{
		return id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	public abstract void calSal();
	public String toString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String doj1 = (doj != null) ? dateFormat.format(doj) : "N/A";
		return " id=" + id +" \n Type="+type+ "\n name=" + name + "\n mobno=" + mobno + "\n emailid=" + emailid + "\n dept=" + dept
				+ "\n desg=" + desg + "\n doj=" + doj1 ;
	}
}






