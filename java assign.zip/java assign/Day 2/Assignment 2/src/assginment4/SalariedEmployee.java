package assginment4;

import java.util.Date;

public class SalariedEmployee extends Employee{

	private long salary;
	
	public SalariedEmployee()
	{
		super();
		salary=0;
	}
	
	public SalariedEmployee( String name, String mobno, String emailid, String dept, String desg, Date doj,long salary)
	{
		super("Salaried Employee",name,mobno,emailid,dept,desg,doj);
		this.salary=salary;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public String toString() {
		return super.toString()+"\n salary=" + salary +"\n-----------------------------------";
	}

	@Override
	public void calSal() {
		
		//calculating salary for salaried employee
		
		double da=(salary*0.10);
		double hra=(salary*0.15);
		double pf=(salary*0.12);
		long sal=(long) (salary+da+hra+pf);
		System.out.println(" having salary "+sal+" Rs.");
		
	}
}



