package assginment3;

public class hobbies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
