package com.demo.beans;

import java.util.Arrays;

public class Vendors extends ABCTel {

	private String phoneno;
	private String[] products;
	
	public Vendors()
	{
		super();
		phoneno=null;
		products=null;
	}
	public Vendors(String name,String email,String phoneno,String[] products)
	{
		super("customer",name,email);
		this.phoneno=phoneno;
		this.products=products;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public String[] getProducts() {
		return products;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public void setProducts(String[] products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return super.toString()+"\n phoneno:" + phoneno + "\n products:" + Arrays.toString(products);
	}
	
}
