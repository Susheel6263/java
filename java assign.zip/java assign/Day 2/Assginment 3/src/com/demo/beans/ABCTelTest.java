package com.demo.beans;

public class ABCTelTest {

	public static void main(String[] args) {
		String[] list={"Product A", "Product B", "Product C"};
		ABCTel a1=new Vendors("Kiran Lambte","kiranlambte12@gmail.com","7620804791",list);
        System.out.println(a1);
        
        System.out.println("-------------------------------------------------------");
        int[] number= {4556,12654,2542};
        ABCTel a2=new Customers("Company","kiran lambate","kiranlambet12@gmail.com","A+",15,"A","true","true","true",number);
        System.out.println(a2);
        
        System.out.println("-------------------------------------------------------");
        ABCTel a3=new Customers("idividual","vinayak lambate","vinayaklambet12@gmail.com","A+",15,"A","789556858");
        System.out.println(a3);
	}

}
