package com.demo.beans;

public class ABCTel {

	private String type;
	private String id;
	private String name;
	private String email;
	private static int c1;
	private static int c2;
	static {
		c1=0;
		c2=0;
	}
	
	public ABCTel()
	{
		type="company";
		id=null;
		name=null;
		email=null;
	}
	public ABCTel(String type,String name,String email)
	{
		this.type=type;
		this.id=generateId();
		this.name=name;
		this.email=email;
	}
	private String generateId() {
		
		if(type=="customer")
		{
			c1++;
		   return ("cus"+c1);
		}
		else
		{
			c2++;
			return ("ven"+c2);
		}
	}
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	public String getType() {
		return type;
	}
	public String getId() {
		return id;
	}
	public String getEmail() {
		return email;
	}
	public void setType(String type) {
		this.type = type;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String toString()
	{
		return " Id:"+id+"\n Name:"+name+"\n Email:"+email;
	}
}
