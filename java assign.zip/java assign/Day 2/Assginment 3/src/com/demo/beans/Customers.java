package com.demo.beans;

import java.util.Arrays;

public class Customers extends ABCTel{
	
	private String creditclass;
	private int discount;
	private String plan;
	private String type;
	private String phoneno;
	private String relationship;
	private String creditline;
	private String extension;
	private int[] number;
	
	public Customers()
	{
		super();
		creditclass=null;
		discount=0;
		plan=null;
		type=null;
		phoneno=null;
		relationship=null;
		creditline=null;
		extension=null;
		number=null;
	}
	
	public Customers(String type,String name,String email,String creditclass,int discount,String plan,String phoneno )
	{
		super("vender",name,email);
		this.type=type;
		this.creditclass=creditclass;
		this.discount=discount;
		this.plan=plan;
		this.phoneno=phoneno;
	}

	public Customers(String type,String name,String email,String creditclass,int discount,String plan,String relationship,String creditline,String extension,int[] number)
	{
		super("vender",name,email);
		this.type=type;
		this.creditclass=creditclass;
		this.discount=discount;
		this.plan=plan;
		this.relationship=relationship;
		this.creditline=creditline;
		this.extension=extension;
		this.number=number;
	}

	@Override
	public String toString() {
		if(type=="idividual") {
		return super.toString()+"\n creditclass:" + creditclass + "\n discount:" + discount + "\n plan:" + plan + "\n type:" + type
				+ "\n phoneno:" + phoneno  ;
		}
		else
		{
			return super.toString()+"\n creditclass:" + creditclass + "\n discount:" + discount + "\n plan:" + plan + "\n type:" + type
					 +"\n relationship:"+ relationship +"\n creditline:"+creditline+"\n extension:"+extension+"\n number"+ Arrays.toString(number);
		}
	}

	public String getCreditclass() {
		return creditclass;
	}

	public int getDiscount() {     
		return discount;
	}

	public String getPlan() {
		return plan;
	}

	public String getType() {
		return type;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public String getRelationship() {
		return relationship;
	}

	public String getCreditline() {
		return creditline;
	}

	public String getExtension() {
		return extension;
	}

	public int[] getNumber() {
		return number;
	}

	public void setCreditclass(String creditclass) {
		this.creditclass = creditclass;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public void setCreditline(String creditline) {
		this.creditline = creditline;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public void setNumber(int[] number) {
		this.number = number;
	}
}























