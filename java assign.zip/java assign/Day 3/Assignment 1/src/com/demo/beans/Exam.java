package com.demo.beans;

import java.util.Date;
import java.util.Scanner;


public class Exam {

	private double examid;
	private String name;
	private String topic;
	private Date doe;
	private static Questions[] qarr;
	static {
		
	}
	
	public Exam() {
		super();
		this.examid=0;
		this.name=null;
		this.topic=null;
		this.doe=null;
		this.qarr=null;
	}
	public Exam(double examid,String name,String topic,Questions[] qarr) {
	    super();
	    this.examid=examid;
	    this.name=name;
	    this.topic=topic;
	    this.qarr=qarr;
//	    this.doe=generateDate();
	    
	}
	public int conductExam() {
        Scanner sc = new Scanner(System.in);
        int totalMarks = 0;
        for (Questions q : qarr) {
            System.out.println(q.qno + ". " + q.question);
            System.out.println("1. " + q.opt1);
            System.out.println("2. " + q.opt2);
            System.out.println("3. " + q.opt3);
            System.out.println("4. " + q.opt4);
            System.out.print("Your answer: ");
            int userAns = sc.nextInt();
            if (userAns == q.ans) {
                totalMarks += 1;
            }
        }
        return totalMarks;
    }
	public String getName() {
		return name;
	}
	public String getTopic() {
		return topic;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public double getExamid() {
		return examid;
	}
	public Date getDoe() {
		return doe;
	}
}
