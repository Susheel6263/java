package com.demo.test;

import java.util.Scanner;
import com.demo.beans.Questions;
import com.demo.beans.Exam;
public class ExamTest {

	public static void main(String[] args) {
		Questions[] javaQuestions = {
	            new Questions(1, "What is Java?", "A programming language", "A coffee", "An island", "A car", 1),
	            new Questions(2, "Which company developed Java?", "Microsoft", "Apple", "Sun Microsystems", "Google", 3),
	            new Questions(3, "Java is a...", "Procedural language", "Functional language", "Object-oriented language", "Scripting language", 3),
	            new Questions(4, "Which of these is not a Java feature?", "Object-oriented", "Use of pointers", "Portable", "Dynamic", 2),
	            new Questions(5, "Which is used to find and fix bugs in Java programs?", "JVM", "JRE", "JDK", "JDB", 4)
	        };
		Questions[] htmlQuestions = {
	            new Questions(1, "What does HTML stand for?", "Hyper Text Markup Language", "Home Tool Markup Language", "Hyperlinks and Text Markup Language", "Hyperlinking Text Marking Language", 1),
	            new Questions(2, "Who is making the Web standards?", "Mozilla", "Microsoft", "Google", "The World Wide Web Consortium", 4),
	            new Questions(3, "Choose the correct HTML element for the largest heading:", "<heading>", "<h6>", "<head>", "<h1>", 4),
	            new Questions(4, "What is the correct HTML element for inserting a line break?", "<br>", "<lb>", "<break>", "<line>", 1),
	            new Questions(5, "What is the correct HTML for adding a background color?", "<body bg='yellow'>", "<background>yellow</background>", "<body style='background-color:yellow;'>", "<bgcolor>yellow</bgcolor>", 3)
	        };
		Scanner sc=new Scanner(System.in);
		char choice;
		do {
			System.out.println("Enter Examid:");
			double examid=sc.nextDouble();
			System.out.println("Enter Name:");
			String name=sc.nextLine();
			sc.nextLine();
			System.out.println("Choose Topic:\n1.java\n2.html\nEnter Topic:");
			int topic=sc.nextInt();
			int marks=0;
			switch(topic) {
			case 1:
				 Exam javaExam = new Exam(14578, name, "Java Programming", javaQuestions);
				 marks = javaExam.conductExam();
			     break;
			case 2:
				Exam htmlExam = new Exam(examid, name, "HTML Basics", htmlQuestions);
				 marks = htmlExam.conductExam();
				 break;
			default:
				System.out.println("Enter valid topic");
			}
			if(marks>=3) {
				System.out.println("Correct Answer: "+marks+" out of 5");
				System.out.println("Congratulations you completed the test......");
			}else {
				System.out.println("Correct Answer: "+marks+" out of 5");
				System.out.println("Better luck next time");
			}
			System.out.println("Do you want to continue????");
			choice=sc.next().charAt(0);
			if(choice=='n') {
				sc.close();
				System.out.println("Thanks for coming....");
			}
		}while(choice=='Y' || choice=='y');

	}

}
