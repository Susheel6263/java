package com.demo.service;

import java.util.Set;
import java.util.Scanner;

import com.demo.beans.Employee;
import com.demo.dao.EmployeeDao;
import com.demo.dao.EmployeeDaoImpl;

public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDao edao;
	Scanner sc=new Scanner(System.in);
	public EmployeeServiceImpl() {
		edao=new EmployeeDaoImpl();
	}
	@Override
	public boolean addNewEmployee() {
		System.out.println("Enter Id:");
		int id=sc.nextInt();
		System.out.println("Enter Name:");
		sc.nextLine();
		String name=sc.nextLine();
		
		System.out.println("Enter Salary:");
		double salary=sc.nextDouble();
		System.out.println("Enter Department:");
		String dept=sc.next();
		System.out.println("Enter Designation:");
		String desg=sc.next();
		Employee e=new Employee(id,name,salary,dept,desg);
		return edao.save(e);
	}
	@Override
	public Set<Employee> displayAll() {
		return edao.findAll();
	}
	@Override
	public Employee displayById(int id) {
	    return edao.findById(id);
	}
	@Override
	public boolean deleteById(int id) {
		return edao.removeById(id);
	}
}
