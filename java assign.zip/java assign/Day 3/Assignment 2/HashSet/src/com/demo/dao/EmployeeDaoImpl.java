package com.demo.dao;

import java.util.Set;
import java.util.HashSet;

import com.demo.beans.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	static Set<Employee> eset;
	static {
		eset=new HashSet<>();
		eset.add(new Employee(10,"kiran Lambate",85000,"developer","manager"));
	}
	@Override
	public boolean save(Employee e) {
		for(Employee e1:eset) {
			if(e1.getId()==e.getId()) {
				return false;
			}else {
				eset.add(e);
			}
		}
		
		return true;
	}
	@Override
	public Set<Employee> findAll() {
		return eset;
	}
	@Override
	public Employee findById(int id) {
		for(Employee e:eset) {
			if(e.getId()==id) {
				return e;
			}
		}
		return null;
	}
	@Override
	public boolean removeById(int id) {
		for(Employee e:eset) {
			if(e.getId()==id) {
				eset.remove(e);
				return true;
			}
		}
		return false;
	}
}
