package com.demo.test;

import java.util.Scanner;
import java.util.Set;

import com.demo.service.EmployeeServiceImpl;
import com.demo.beans.Employee;
import com.demo.service.EmployeeService;
public class EmployeeTest {

	public static void main(String[] args) {
		EmployeeService eservice=new EmployeeServiceImpl();
		Scanner sc=new Scanner(System.in);
		int choice=0;
		do {
			System.out.println("1.Add New Employee\n2.Display All\n3.Display By ID\n4.Delete By ID\n5.Exit\nEnter Choice:");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				boolean status=eservice.addNewEmployee();
				if(status) {
					System.out.println("Employee Added Successfully....");
				}else {
					System.out.println("Duplicate Entry....");
				}
				break;
			case 2:
				Set<Employee> eset=eservice.displayAll();
				if(eset.size()>0) {
				eset.forEach(e->{
					System.out.println(e);
				});}else {
					System.out.println("No employee's....");
				}
				break;
			case 3:
				System.out.println("Enter Id Of An Employee:");
				int id=sc.nextInt();
				Employee e=eservice.displayById(id);
				if(e!=null) {
				System.out.println(e);
				}else {
					System.out.println("Employee Not Found.....");
				}
				break;
			case 4:
				System.out.println("Enter Id Of An Employee:");
			    id=sc.nextInt();
			    status =eservice.deleteById(id);
			    if(status) {
					System.out.println("Employee Deleted Successfully....");
				}else {
					System.out.println("Employee Not Found....");
				}
				break;
			case 5:sc.close();
			    System.out.println("Thanks For Coming......");
			    break;
			default:
				System.out.println("Wrong Choice.......");
			}
		}while(choice!=5);

	}

}
