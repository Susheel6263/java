package assginment2;

import java.util.Scanner;

public class StudentsInfo {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in); 
		int choice=0;
		do {
			System.out.println("1.Display All Students Information \n 2.Search Student By Id \n 3.Search Student By Name \n 4.Calculate GPA Of Student \n 5.Exit");
			System.out.println("Enter Your Choice:");
			choice=sc.nextInt(); 
			switch(choice)
			{
			case 1:StudentsInfoTest.displayData();
			    break;
			case 2:System.out.println("Enter Id of a Student:");
			       int id=sc.nextInt();
				StudentsInfoTest.studentById(id);
			    break;
			case 3:System.out.println("enter name of a student");
			       sc.nextLine();
			       String name=sc.nextLine();
				StudentsInfoTest.sudentByName(name);
				break;
			case 4:System.out.println("Enter Marks 1:");
		       int m1=sc.nextInt();
		       System.out.println("Enter Marks 2:");
		       int m2=sc.nextInt();
		       System.out.println("Enter Marks 3:");
		       int m3=sc.nextInt();
				StudentsInfoTest.calculateGpa(m1,m2,m3);
				break;
			case 5:
				sc.close();
				System.exit(0);
				System.out.println("Thanks for coming in iet........");
		        break;
			default:System.out.println("Wrong Choice");
			}
		}while(choice!=5);
	}

}
