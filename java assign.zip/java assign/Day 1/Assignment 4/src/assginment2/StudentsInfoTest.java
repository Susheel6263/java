package assginment2;
public class StudentsInfoTest {
	static Student[] stud=new Student[10];
    static {
    	stud[0]=new Student(101,"omkar",89,94,56);
    	stud[1]=new Student(102,"omkar",59,84,87);
    	stud[2]=new Student(103,"sahil",56,47,66);
    	stud[3]=new Student(104,"aditya",77,68,74);
    	stud[4]=new Student(105,"adarash",93,45,62);
    	stud[5]=new Student(106,"karan",83,91,58);
    	stud[6]=new Student(106,"tanmay",76,59,65);
    	stud[7]=new Student(107,"kiran",67,27,37);
    	stud[8]=new Student(108,"sheeba",98,97,99);
    	stud[9]=new Student(109,"saakshi",67,65,75);
    }
	
	public static void displayData() {
		
		// displaying student information
		
		for(int i=0;i<stud.length;i++)
		{
			System.out.println(stud[i]);
		}
	}

	public static void studentById(int id) {
		
		for(int i=0;i<stud.length;i++) {
        if(stud[i].getStudid()==id) {
        System.out.println(stud[i]);	
        }
		}
		
	}

	public static void sudentByName(String name) {
		
		for(int i=0;i<stud.length;i++) {
	        if(stud[i].getName().equals(name)) {
	        System.out.println(stud[i]);	
	        }
			}
		
	}

	public static void calculateGpa(int m1,int m2,int m3) {
		
		float gpa=(float)((1.0/3.0) * m1 + (1.0/2.0) * m2 + (1.0/4.0) * m3);
		System.out.println("GPA of a student:"+gpa);
	}
		
	}

