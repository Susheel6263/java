class PrimeTable{
	public static void primeNumber(String[] args)
	{
		for(int i=0;i<args.length;i++)
		{
			int numi=Integer.parseInt(args[i]);
			int c=0;
			for(int j=1;j<=numi;j++)
			{
				if(numi%j==0)
				{
					c++;
				}
		}
		if(c==2)
			{
				for(int k=1;k<11;k++)
				{
				System.out.print(numi+"*"+k+"="+(numi*k)+"\n");
				}
				System.out.print("----------------------------------");
				System.out.println();
			}
			else{
				float b=(float)numi/10;
				System.out.println("output="+b);
				System.out.print("_________ \n");
	       }
	}
	}
public static void main(String[] args)
{
	if(args.length==3)
	{
       	primeNumber(args);
	}
	else
	{
		System.out.println("Atleast 3 arguments.............");
	}
	
}
}
	