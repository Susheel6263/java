package assginment3;

public class FriendsTest {

	public static void main(String[] args) {
		

	}

}
