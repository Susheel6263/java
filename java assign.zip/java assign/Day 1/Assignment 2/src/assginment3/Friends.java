package assginment3;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Friends {

	private int id;
	private String name;
	private String lastname;
	private String[] hobbies;
	private String mobno;
	private String email;
	private Date bdate;
	private String address; 

	public Friends()
	{
		id=0;
		name=null;
		lastname=null;
		hobbies=null;
		mobno=null;
		email=null;
		bdate=null;
		address=null;
	}
	
	public Friends(int id,String name,String lastname,String[] hobbies,String mobno,String email,Date bdate,String address) {
		this.id=id;
		this.name=name;
		this.lastname=lastname;
		this.hobbies=hobbies;
		this.mobno=mobno;
		this.email=email;
		this.bdate=bdate;
		this.address=address;
	}
	public void setId(int id)
	{
		this.id=id;
	}
	public void setName(String name)
	{
		this.name=name;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getLastname() {
		return lastname;
	}

	public String[] getHobbies() {
		return hobbies;
	}

	public String getMobno() {
		return mobno;
	}

	public String getEmail() {
		return email;
	}

	public Date getBdate() {
		return bdate;
	}

	public String getAddress() {
		return address;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	public String toString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String bdate1 = (bdate != null) ? dateFormat.format(bdate) : "N/A";
		return "id: " + id + "\n name: " + name + "\n lastname: " + lastname + "\n hobbies: "
				+ Arrays.toString(hobbies) + "\n mobno: " + mobno + "\n email: " + email + "\n bdate: " + bdate1 + "\n address: "
				+ address;
	}
}















































