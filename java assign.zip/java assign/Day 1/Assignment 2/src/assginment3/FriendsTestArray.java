package assginment3;
import java.util.Scanner;
public class FriendsTestArray {

	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		int choice;
		do {
			System.out.println("1.Accept friends details \n 2.Display All Friend \n 3.Search by id \n 4.Search by name \n 5. Display all friend with a particular hobby  \n 6.Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			sc.nextLine();
			switch(choice) {
			case 1:FriendsService.accptData();
				break;
			case 2:FriendsService.displayAll();
				break;
			case 3:FriendsService.serachById();
				break;
			case 4:System.out.println("Enter name of a friend to search:");
            String name = sc.nextLine();
				Friends[] friendsByName = FriendsService.searchByName(name); // Assuming this returns an array
            if (friendsByName != null && friendsByName.length > 0) {
                System.out.println("--- Friends found with name '" + name + "' ---");
                for (Friends friend : friendsByName) {
                    System.out.println(friend);
                }}
				break;
			case 5:	  System.out.println("Enter hobby to search for:");
            String hobby = sc.nextLine();
            Friends[] friendsWithHobby = FriendsService.allFriendsWithSameHobby(hobby); // Assuming this returns an array
            if (friendsWithHobby != null && friendsWithHobby.length > 0) {
                System.out.println("--- Friends with hobby '" + hobby + "' ---");
                for (Friends friend : friendsWithHobby) {
                    System.out.println(friend);
                    System.out.println("--------------------");
                }
            } else {
                System.out.println("No friends found with the hobby '" + hobby + "'.");
            }
				break;
			case 6:sc.close();
			System.out.println("thanks for coming......");
				break;
			default: System.out.println("wrong choice........"); 
			}
		}while(choice!=6); 
	}
}
