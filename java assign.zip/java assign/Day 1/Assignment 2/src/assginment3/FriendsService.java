package assginment3;
import java.util.Date;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class FriendsService {
 
	static Friends[] fr=new Friends[10];
	static int c;
	static Scanner sc=new Scanner(System.in);
	static {
		c=0;
	}
	public static void accptData() {
		
		//Accepting friends information
		
		
		if(fr.length>=10)
		{
			System.out.println("Enter id of a friend:");
			int id=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter name of a friend:");
			String name=sc.nextLine(); 
			System.out.println("Enter lastname of a friend:");
			String lastname=sc.nextLine();
			System.out.println("Enter friends hobbie:");
			String[] hobbies = new String[5];
			for(int i=0;i<5;i++)
			{
				 hobbies[i]=sc.nextLine();
			}
			System.out.println("Enter mobile of a friend:");
			String mobno=sc.nextLine();
			System.out.println("Enter email of a friend:");
			String email=sc.nextLine();
	
			System.out.println("Enter birtdate of a friend:");
			String birthdayString = sc.nextLine();

			SimpleDateFormat bdateFormatter = new SimpleDateFormat("dd/MM/yyyy");
			Date bdate = null;
			try {
			    bdate = bdateFormatter.parse(birthdayString);
			} catch (ParseException e) {
			    System.out.println("Invalid date format. Please use dd/MM/yyyy.");
			    return; // Exit the method if the date format is invalid
			}
			System.out.println("Enter address of a friend:");
			String address=sc.nextLine();
			fr[c]=new Friends(id,name,lastname,hobbies,mobno,email,bdate,address);
					c++;
					System.out.println("Friend added successfully!");
		}
		else {
			System.out.println("no mores friends!!!!!!!!!"); 
		}
		
	}
	public static void displayAll() {
		
		// Displaying details of a friends
		
		if(c>0)
		{
			for(int i=0;i<c;i++)
			{
				System.out.println(fr[i]);
			}
		}
		else
		{
			System.out.println("no friends to display!!!");
		}
	}
	public static Friends[] searchByName(String name) {
		
		//Searching friend by name
		
		if(c>0)
		{
			Friends[] fr1=new Friends[c];
			int b = 0;
			for(int i=0;i<c;i++)
			{
				if(fr[i].getName().equals(name))
				{
					 fr1[b]=fr[i];
					 b++;
				}
			}
			return fr1;
		}
		return null;
		
	}
	public static Friends[] allFriendsWithSameHobby(String hobby) {
		
		//Same hobby friends
		
		if(c>0)
		{
			Friends[] fr1=new Friends[c];
			int b = 0;
		for(int i=0;i<c;i++)
		{
			if(fr[i].getHobbies().equals(hobby))
			{
				fr1[b]=fr[i];
				 b++;
			}
		}
		return fr1;
		}
		return null;

	}
	public static void serachById() {
		// searching friend by id
		
		System.out.println("enter id:");
		int id=sc.nextInt();
		if(c>0)
		{
			for(int i=0;i<c;i++)
			{
				if(fr[i].getId()==id)
				{
					System.out.println(fr[i]);
				}
			}

		}
		
	}
	

}
