package assginment2;

public class StudentsService {
	public static void main(String[] args)
	{
		Student s=new Student();
		System.out.println(s);
	}
	
	
}
