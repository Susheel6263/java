package assginment2;
import java.util.Scanner;
public class StudentsInfoTest {
	static Student[] stud=new Student[10];
    static int count;
    static {
    	count=0;
    }
	static Scanner sc=new Scanner(System.in);

	public static void acceptData() {
		
		// accepting student information
		
		System.out.println("Enter Student Name:");
		String name=sc.nextLine();
		sc.nextLine();
		System.out.println("Enter m1:");
		int m1=sc.nextInt();
		System.out.println("Enter m2:");
		int m2=sc.nextInt();
		System.out.println("Enter m3:");
		int m3=sc.nextInt();
		stud[count]=new Student(name,m1,m2,m3);
		count++;
		System.out.println("Student Added...............");
	}

	public static void displayData() {
		
		// displaying student information
		
		if(count!=0) {
		for(int i=0;i<count;i++)
		{
			System.out.println(stud[i]);
		}
	}
		else
		{
			System.out.println("College is Closed!!!!!!!!!!");
			
		}
	}
}
