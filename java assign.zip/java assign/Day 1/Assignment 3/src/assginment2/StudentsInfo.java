package assginment2;

import java.util.Scanner;

public class StudentsInfo {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in); 
		int choice=0;
		do {
			System.out.println("1.Add Students Information \n 2.Display All Students Information \n 3.Exit");
			System.out.println("Enter Your Choice:");
			choice=sc.nextInt(); 
			switch(choice)
			{
			case 1:StudentsInfoTest.acceptData();
			break;
			case 2:StudentsInfoTest.displayData();
			break;
			case 3:
				sc.close();
				System.exit(0);
				System.out.println("Thanks for coming in iet........");
		    break;
			default:System.out.println("Wrong Choice");
			}
		}while(choice!=3);
	}

}
