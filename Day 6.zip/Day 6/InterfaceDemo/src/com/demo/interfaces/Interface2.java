package com.demo.interfaces;

public interface Interface2 {
  void m21() ;
  
}
