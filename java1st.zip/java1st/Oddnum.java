class Oddnum{
   public static int odd(int n){
   for(int i=1; i<=n; i++){
   if(i%2==1){
   System.out.println(i);}
   }
   return 1;
   }
   
    public static void main(String[] args){
	if(args.length==1){
	int n=odd(Integer.parseInt(args[0]));
	}
	else{
        System.out.println("Too args should be there");
		}
		
	}
}