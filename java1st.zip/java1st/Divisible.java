class Divisible{
    public static int div(int n){
	if(n%3==0){}
	return 1;
	}
	
public static void main(String[] args){
    int sum=0;
	if(args.length>=1){
	for(int i=0; i<args.length; i++){
		int c = Integer.parseInt(args[i]);
	sum=sum+div(c);
	}
	System.out.println("All numbers sum that are div by 3 "+sum);
	}
	else{
        System.out.println("Too args should be there");
		}
}
	}