import java.util.*;
class AddNumbers1{
public static void main(String args[]){
Scanner sc = new Scanner(System.in);
System.out.println("enter number");
int num1 = sc.nextInt();
System.out.println("enetr new number");
int num2 = sc.nextInt();
System.out.println("addition of two numbers is: "+(num1+num2));
}}
