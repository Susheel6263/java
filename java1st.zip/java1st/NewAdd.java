import java.util.*;
class NewAdd{
public static void main(String args[]){
System.out.println("enter the numbers: ");
Scanner sc=new Scanner(System.in);
int num1 = sc.nextInt();
System.out.println("enetr the second number");
int num2 = sc.nextInt();
System.out.println("the addition of two numbers are "+(num1+num2));
}
}