class MulCmd{
	//logic for multipication 
public static void multiply(int n){
for(int i = 1; i<=10;i++)
    System.out.println("The multi of "+n+" * "+i+" is "+n*i);

}

public static void main(String args[]){
	System.out.println("the multiplication of number 5 is ");
	
	if(args.length==1){
	multiply(Integer.parseInt(args[0]));
		//return multiplication 
		
	}
	else {
	System.out.println("give some args");}
}
}