import java.util.*;
class MaxNos{
	public static void main(String args[]){
		if(args.length>=2){
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			
			if (num1>num2){
				
				System.out.println("Max number is "+num1);
			}
			else {
				System.out.println("max number is "+num2);
			}
		}
	}
}