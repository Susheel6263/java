class Primme{
       public static boolean isPrime(int n){
	   for(int i=2; i<n; i++){
	   if(n%i==0){
	   return false;}
	   }
	   return true;
	   }
	   public static void main(String args[]){
	   if(args.length>=1){
	   for(int i=0; i<args.length; i++){
	   boolean n=isPrime(Integer.parseInt(args[i]));
	   if(n){
	   System.out.println("Prime is "+args[i]);
	  }
	  else{
	  System.out.println("not Prime is "+args[i]);
	  }
	  }
	  }
	  else{
	  System.out.println("Give some para");
	  
	  }
	  }
	  }
	  

	   
	   
	   